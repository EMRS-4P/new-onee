-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2018 at 02:39 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emrs`
--

-- --------------------------------------------------------

--
-- Table structure for table `clinical_features_bee_stings`
--

CREATE TABLE `clinical_features_bee_stings` (
  `Index_Of_clinical_features_bee_stings` varchar(100) NOT NULL,
  `Index_Of_Bee_Stings` varchar(10000) DEFAULT NULL,
  `Patient_Id` varchar(10000) DEFAULT NULL,
  `Burning_pain` varchar(100) DEFAULT 'no',
  `Swelling` varchar(100) DEFAULT 'no',
  `Pruntus` varchar(100) DEFAULT 'no',
  `Nauka` varchar(100) DEFAULT 'no',
  `Vomiting` varchar(100) DEFAULT 'no',
  `Hypotenisum` varchar(100) DEFAULT 'no',
  `Bronchospasm` varchar(100) DEFAULT 'no',
  `Oliguna` varchar(100) DEFAULT 'no',
  `Renal_failure` varchar(100) DEFAULT 'no',
  `Diarrhoea` varchar(100) DEFAULT 'no',
  `Tightness_of_chest` varchar(100) DEFAULT 'no',
  `Malaise` varchar(100) DEFAULT 'no',
  `Urticana` varchar(100) DEFAULT 'no',
  `Facial_odema` varchar(100) DEFAULT 'no',
  `Laryngeal_odema` varchar(100) DEFAULT 'no',
  `Seizure` varchar(100) DEFAULT 'no',
  `Rhabdomyolysis` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clinical_features_black_widow_spider`
--

CREATE TABLE `clinical_features_black_widow_spider` (
  `Index_Of_clinical_features_black_widow_spider` varchar(100) NOT NULL,
  `Index_Of_Black_Widow_Spider` varchar(1000) DEFAULT NULL,
  `Patient_Id` varchar(10000) DEFAULT NULL,
  `Abdominal_Pain` varchar(100) DEFAULT 'no',
  `Headache` varchar(100) DEFAULT 'no',
  `Narea` varchar(100) DEFAULT 'no',
  `Pain_In _Large_Mscle_Grop` varchar(100) DEFAULT 'no',
  `Pain_At_The_Site` varchar(100) DEFAULT 'no',
  `Pain_In_The_Extremities_With_Weakness` varchar(100) DEFAULT 'no',
  `Prunts` varchar(100) DEFAULT 'no',
  `Urtecana` varchar(100) DEFAULT 'no',
  `Vomiting` varchar(100) DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clinical_features_hornet_stings`
--

CREATE TABLE `clinical_features_hornet_stings` (
  `Index_Of_clinical_features_hornet_stings` varchar(100) NOT NULL,
  `Index_Of_Hornet_Stings` varchar(10000) DEFAULT NULL,
  `Patient_Id` varchar(10000) DEFAULT NULL,
  `Burning_pain` varchar(100) DEFAULT 'no',
  `Swelling` varchar(100) DEFAULT 'no',
  `Pruntus` varchar(100) DEFAULT 'no',
  `Nauka` varchar(100) DEFAULT 'no',
  `Vomiting` varchar(100) DEFAULT 'no',
  `Hypotenisum` varchar(100) DEFAULT 'no',
  `Bronchospasm` varchar(100) DEFAULT 'no',
  `Oliguna` varchar(100) DEFAULT 'no',
  `Renal_failure` varchar(100) DEFAULT 'no',
  `Diarrhoea` varchar(100) DEFAULT 'no',
  `Tightness_of_chest` varchar(100) DEFAULT 'no',
  `Malaise` varchar(100) DEFAULT 'no',
  `Urticana` varchar(100) DEFAULT 'no',
  `Facial_odema` varchar(100) DEFAULT 'no',
  `Laryngeal_odema` varchar(100) DEFAULT 'no',
  `Seizure` varchar(100) DEFAULT 'no',
  `Rhabdomyolysis` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clinical_features_wasp_stings`
--

CREATE TABLE `clinical_features_wasp_stings` (
  `Index_Of_clinical_features_wasp_stings` varchar(100) NOT NULL,
  `Index_Of_Wasp_Stings` varchar(10000) DEFAULT NULL,
  `Patient_Id` varchar(10000) DEFAULT NULL,
  `Burning_pain` varchar(100) DEFAULT 'no',
  `Swelling` varchar(100) DEFAULT 'no',
  `Pruntus` varchar(100) DEFAULT 'no',
  `Nauka` varchar(100) DEFAULT 'no',
  `Vomiting` varchar(100) DEFAULT 'no',
  `Hypotenisum` varchar(100) DEFAULT 'no',
  `Bronchospasm` varchar(100) DEFAULT 'no',
  `Oliguna` varchar(100) DEFAULT 'no',
  `Renal_failure` varchar(100) DEFAULT 'no',
  `Diarrhoea` varchar(100) DEFAULT 'no',
  `Tightness_of_chest` varchar(100) DEFAULT 'no',
  `Malaise` varchar(100) DEFAULT 'no',
  `Urticana` varchar(100) DEFAULT 'no',
  `Facial_odema` varchar(100) DEFAULT 'no',
  `Laryngeal_odema` varchar(100) DEFAULT 'no',
  `Seizure` varchar(100) DEFAULT 'no',
  `Rhabdomyolysis` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `details_about_bee_stings`
--

CREATE TABLE `details_about_bee_stings` (
  `index_of_details_about_bee_stings` varchar(100) NOT NULL,
  `Index_Of_bee_Stings` varchar(100) DEFAULT NULL,
  `Patient_Id` varchar(100) DEFAULT NULL,
  `Time_Of_Stings` time DEFAULT NULL,
  `Number_of_stings` int(255) DEFAULT NULL,
  `Place_Of_Stings` varchar(1000) DEFAULT NULL,
  `Head_and_Neck` varchar(100) DEFAULT 'no',
  `Upper_Limb` varchar(100) DEFAULT 'no',
  `Chest` varchar(100) DEFAULT 'no',
  `Abdomen` varchar(100) DEFAULT 'no',
  `Lower_Limb` varchar(100) DEFAULT 'no',
  `other` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `details_about_black_widow_spider`
--

CREATE TABLE `details_about_black_widow_spider` (
  `index_of_details_about_black_widow_spider` varchar(100) NOT NULL,
  `Index_Of_Black_Widow_Spider` varchar(100) DEFAULT NULL,
  `Patient_Id` varchar(100) DEFAULT NULL,
  `Time_Of_Stings` time(6) DEFAULT NULL,
  `Number_Of_Stings` int(255) DEFAULT NULL,
  `Place_Of_Stings` varchar(1000) DEFAULT NULL,
  `Head_and_Neck` varchar(100) DEFAULT 'no',
  `Upper_Limb` varchar(100) DEFAULT 'no',
  `Chest` varchar(100) DEFAULT 'no',
  `Abdomen` varchar(100) DEFAULT 'no',
  `Lower_Limb` varchar(100) DEFAULT 'no',
  `other` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `details_about_hornet_stings`
--

CREATE TABLE `details_about_hornet_stings` (
  `index_of_details_about_hornet_stings` varchar(100) NOT NULL,
  `Index_Of_hornet_Stings` varchar(100) DEFAULT NULL,
  `Patient_Id` varchar(100) DEFAULT NULL,
  `Time_Of_Stings` time DEFAULT NULL,
  `Number_of_stings` int(255) DEFAULT NULL,
  `Place_Of_Stings` varchar(1000) DEFAULT NULL,
  `Head_and_Neck` varchar(100) DEFAULT 'no',
  `Upper_Limb` varchar(100) DEFAULT 'no',
  `Chest` varchar(100) DEFAULT 'no',
  `Abdomen` varchar(100) DEFAULT 'no',
  `Lower_Limb` varchar(100) DEFAULT 'no',
  `other` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `details_about_wasp_stings`
--

CREATE TABLE `details_about_wasp_stings` (
  `index_of_details_about_wasp_stings` varchar(100) NOT NULL,
  `Index_Of_wasp_Stings` varchar(100) DEFAULT NULL,
  `Patient_Id` varchar(100) DEFAULT NULL,
  `Time_Of_Stings` time DEFAULT NULL,
  `Number_of_stings` int(255) DEFAULT NULL,
  `Place_Of_Stings` varchar(1000) DEFAULT NULL,
  `Head_and_Neck` varchar(100) DEFAULT 'no',
  `Upper_Limb` varchar(100) DEFAULT 'no',
  `Chest` varchar(100) DEFAULT 'no',
  `Abdomen` varchar(100) DEFAULT 'no',
  `Lower_Limb` varchar(100) DEFAULT 'no',
  `other` varchar(100) DEFAULT 'no',
  `Circumstances_Of_Stings` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor_registration`
--

CREATE TABLE `doctor_registration` (
  `Doctor_ID` int(11) NOT NULL,
  `FirstName` varchar(1000) DEFAULT NULL,
  `LastName` varchar(1000) DEFAULT NULL,
  `E_mail` varchar(1000) DEFAULT NULL,
  `Username` varchar(1000) DEFAULT NULL,
  `Password` varchar(1000) DEFAULT NULL,
  `Confirm_Password` varchar(1000) DEFAULT NULL,
  `DateOfBirth` varchar(1000) DEFAULT NULL,
  `Gender` varchar(1000) DEFAULT NULL,
  `Mobile_Number` int(20) DEFAULT NULL,
  `Land_Number` int(20) DEFAULT NULL,
  `Area_Of_Practice` varchar(1000) DEFAULT NULL,
  `Medical_Education` varchar(1000) DEFAULT NULL,
  `Current_Location` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_registration`
--

INSERT INTO `doctor_registration` (`Doctor_ID`, `FirstName`, `LastName`, `E_mail`, `Username`, `Password`, `Confirm_Password`, `DateOfBirth`, `Gender`, `Mobile_Number`, `Land_Number`, `Area_Of_Practice`, `Medical_Education`, `Current_Location`) VALUES
(1, 'name', 'last', 'abc@gmail.com', 'rms', '123', '123', '2018-03-13', 'Female', 1234456, 222, 'NULL', 'NULL', '43 ,er ,Ampara.');

-- --------------------------------------------------------

--
-- Table structure for table `fauna`
--

CREATE TABLE `fauna` (
  `Index_Of_Type_Of_Natural_Toxins` varchar(100) NOT NULL,
  `Index_Of_Fauna` varchar(1000) DEFAULT NULL,
  `Types_Of_Fauna` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `flora`
--

CREATE TABLE `flora` (
  `Index_Of_Type_Of_Natural_Toxins` varchar(100) NOT NULL,
  `Index_Of_Flora` varchar(1000) DEFAULT NULL,
  `Types_Of_Flora` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fungal_poison`
--

CREATE TABLE `fungal_poison` (
  `Index_Of_Type_Of_Natural_Toxins` varchar(100) NOT NULL,
  `Index_Of_Fungal_Poison` varchar(1000) DEFAULT NULL,
  `Type_Of_Fungal_Poison` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `management_of_bee`
--

CREATE TABLE `management_of_bee` (
  `Index_Of_management_Of_Bee` varchar(100) NOT NULL,
  `Index_Of_Bee_Stings` varchar(10000) DEFAULT NULL,
  `Patient_Id` varchar(10000) DEFAULT NULL,
  `Apply_ice_packs` varchar(1000) DEFAULT NULL,
  `Artihistamine` varchar(1000) DEFAULT NULL,
  `Adranaline_IM` varchar(1000) DEFAULT NULL,
  `ICU_care` varchar(1000) DEFAULT NULL,
  `Steroids` varchar(1000) DEFAULT NULL,
  `Need_Renal_Replacement_therapy` varchar(1000) DEFAULT NULL,
  `Need_invasive_ventilation` varchar(1000) DEFAULT NULL,
  `Stinger_scrapped` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `management_of_black_widow_spider`
--

CREATE TABLE `management_of_black_widow_spider` (
  `Index_Of_management_of_black_widow_spider` varchar(100) NOT NULL,
  `Index_Of_Black_Widow_Spider` varchar(1000) DEFAULT NULL,
  `Types_Of_Managements` varchar(1000) DEFAULT NULL,
  `Yes_Or_No` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `management_of_hornet`
--

CREATE TABLE `management_of_hornet` (
  `Index_Of_management_Of_Hornet` varchar(100) NOT NULL,
  `Index_Of_Hornet_Stings` varchar(10000) DEFAULT NULL,
  `Types_Of_Managements` varchar(1000) DEFAULT NULL,
  `Yes_Or_No` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `management_of_wasp`
--

CREATE TABLE `management_of_wasp` (
  `Index_Of_management_Of_Wasp` varchar(100) NOT NULL,
  `Index_Of_Wasp_Stings` varchar(10000) DEFAULT NULL,
  `Types_Of_Managements` varchar(1000) DEFAULT NULL,
  `Yes_Or_No` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `microbial_poison`
--

CREATE TABLE `microbial_poison` (
  `Index_Of_Type_Of_Natural_Toxins` varchar(100) NOT NULL,
  `Index_Of_Microbial_Poison` varchar(1000) DEFAULT NULL,
  `Type_Of_Microbial_Poison` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `natural_toxins`
--

CREATE TABLE `natural_toxins` (
  `Index_Of_Type_Of_Poison` varchar(100) NOT NULL,
  `Index_Of_Natural_Toxins` varchar(1000) DEFAULT NULL,
  `Type_Of_Natural_Toxins` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient_registration`
--

CREATE TABLE `patient_registration` (
  `Registration_Number` int(11) NOT NULL,
  `FirstName` varchar(10000) DEFAULT NULL,
  `LastName` varchar(10000) DEFAULT NULL,
  `medical_history` varchar(10000) DEFAULT NULL,
  `patient_NIC` varchar(34) NOT NULL,
  `guardian_name` varchar(120) NOT NULL,
  `guardian_phonenumber` varchar(123) NOT NULL,
  `guardian_address` varchar(123) NOT NULL,
  `Date_Of_Birth` date DEFAULT NULL,
  `Gender` varchar(10000) DEFAULT NULL,
  `mobile_number` varchar(34) NOT NULL,
  `land_number` varchar(34) NOT NULL,
  `address` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_registration`
--

INSERT INTO `patient_registration` (`Registration_Number`, `FirstName`, `LastName`, `medical_history`, `patient_NIC`, `guardian_name`, `guardian_phonenumber`, `guardian_address`, `Date_Of_Birth`, `Gender`, `mobile_number`, `land_number`, `address`) VALUES
(1, 'name', 'last', 'de', '123444', '34', '34', '', '2018-03-13', 'Male', '1234456', '222', '43 ,er ,Ampara.');

-- --------------------------------------------------------

--
-- Table structure for table `place_of_stings_bee_stings`
--

CREATE TABLE `place_of_stings_bee_stings` (
  `Index_Of_place_of_stings_Bee_Stings` varchar(100) NOT NULL,
  `Index_Of_Bee_Stings` varchar(1000) DEFAULT NULL,
  `Place` varchar(10000) DEFAULT NULL,
  `Sub_Place` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `place_of_stings_black_widow_spider`
--

CREATE TABLE `place_of_stings_black_widow_spider` (
  `Index_Of_place_of_stings_black_widow_spider` varchar(100) NOT NULL,
  `Index_Of_Black_Widow_Spider` varchar(1000) DEFAULT NULL,
  `Place` varchar(1000) DEFAULT NULL,
  `Sub_Place` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `place_of_stings_hornet_stings`
--

CREATE TABLE `place_of_stings_hornet_stings` (
  `Index_Of_place_of_stings_Hornet_Stings` varchar(100) NOT NULL,
  `Index_Of_Hornet_Stings` varchar(1000) DEFAULT NULL,
  `Place` varchar(10000) DEFAULT NULL,
  `Sub_Place` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `place_of_stings_wasp_stings`
--

CREATE TABLE `place_of_stings_wasp_stings` (
  `Index_Of_place_of_stings_Wasp_Stings` varchar(100) NOT NULL,
  `Index_Of_Wasp_Stings` varchar(1000) DEFAULT NULL,
  `Place` varchar(10000) DEFAULT NULL,
  `Sub_Place` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `poison`
--

CREATE TABLE `poison` (
  `Index_Of_Poison` varchar(100) NOT NULL,
  `Type_Of_Poison` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receptionist_registration`
--

CREATE TABLE `receptionist_registration` (
  `receptionist_regno` int(11) NOT NULL,
  `FirstName` varchar(10000) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `E_mail` varchar(100) DEFAULT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(34) NOT NULL,
  `Date_Of_Birth` date DEFAULT NULL,
  `Gender` varchar(10000) DEFAULT NULL,
  `Mobile_Number` varchar(34) NOT NULL,
  `Land_Number` varchar(34) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receptionist_registration`
--

INSERT INTO `receptionist_registration` (`receptionist_regno`, `FirstName`, `LastName`, `E_mail`, `Username`, `Password`, `Date_Of_Birth`, `Gender`, `Mobile_Number`, `Land_Number`) VALUES
(1, 'namef', 'namel', 'abc@gmail.com', 'abc', '123', '2018-01-13', 'Male', '1234456', '222'),
(2, 'name', 'last', 'a@gmail.com', 'rmss', '123', '2018-03-13', 'Male', '1234456', '222');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor_registration`
--
ALTER TABLE `doctor_registration`
  ADD PRIMARY KEY (`Doctor_ID`);

--
-- Indexes for table `patient_registration`
--
ALTER TABLE `patient_registration`
  ADD PRIMARY KEY (`Registration_Number`);

--
-- Indexes for table `receptionist_registration`
--
ALTER TABLE `receptionist_registration`
  ADD PRIMARY KEY (`receptionist_regno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor_registration`
--
ALTER TABLE `doctor_registration`
  MODIFY `Doctor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `patient_registration`
--
ALTER TABLE `patient_registration`
  MODIFY `Registration_Number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `receptionist_registration`
--
ALTER TABLE `receptionist_registration`
  MODIFY `receptionist_regno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
