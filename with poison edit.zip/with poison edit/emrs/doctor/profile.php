<?php 
//check for a form subbmission
if(isset($_GET['username'])){
	$username = $_GET['username'];
	mysql_connect("localhost","root","") or die("Could not be connect to the server");
	mysql_select_db("emrs") or die ("That database could not be found");
	
	
	$userquery = mysql_query("SELECT * FROM users WHERE username ='$username'") or die("The query cold not be completed,please try again");
	if (mysql_num_rows($username) != 1){
		die("That user name cold not be found");
	}
	
	while($row = mysql_fetch_array($username,MYSQL_ASSOC)){
		$firstname = $row['firstname'];
		$lastname = $row['lastname'];
		$email = $row['email'];
		$dbusername = $row['username'];
		$activated = $row['activated'];
		$access = $row['access'];
	}
		if($usrename != $dbusername){
			die ("There has been a error.please try again.");
		}
		if($activated == 0){
			$active = "The account is not been activated";
		}
		else{
			$active = "The account has been activated";
		}
		//see what level of access the user has
		if($access == 0){
			$admin = "This user is not an administrator";
		}
		else{
			$admin = "This user is an administrator";
		}
?>


<html>
<head>
	<title><?php echo $firstname; ?>s Profile</title>
</head>
<body>

	<h2><?php echo $firstname;?><?php echo $lastname; ?>'s profile</h2><br />
	<table>
		<tr><td>Firstname:</td><td><?php echo $firstname; ?></td></tr>
		<tr><td>Lastname:</td><td><?php echo $lastname; ?></td></tr>
		<tr><td>Email:</td><td><?php echo $email ?></td></tr>
		<tr><td>Username:</td><td><?php echo $dbusername; ?></td></tr>
		<tr><td>Activated:</td><td><?php echo $active; ?></td></tr>
		<tr><td>Access:</td><td><?php echo $admin; ?></td></tr>
	</table>

</body>

</html>
