<?PHP
	session_start();
	require_once('../connection/connect.php');
	
	$UserName = $_SESSION["username"];
	$password = $_SESSION["password"];
	$query ="select * from doctor_registration where Username='$UserName' and Password ='$password'";
	
	$result =mysqli_query($connection,$query);
	
	$doctor_details = mysqli_fetch_assoc($result);
	
?>
<!doctype html>

<html lang="en-gb" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title>Regional Poison Information System</title>
<meta name="description" content="">
<meta name="author" content="Group4p">

<link rel="stylesheet" href="../css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="../css/isotope.css" media="screen" />
<link rel="stylesheet" href="../js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
<link href="../css/animate.css" rel="stylesheet" media="screen">
<!-- Owl Carousel Assets -->
<link href="../js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="../css/styles.css" />
<!-- Font Awesome -->
<link href="../font/css/font-awesome.min.css" rel="stylesheet">

<style>
.column {
    float: left;
    width: 50%;
    padding: 10px;
}


.row:after {
    content: "";
    display: table;
    clear: both;
} 

.not-active:link {
    color: #000000;
	text-decoration:none;
}

/* visited link */
.not-active:visited {
    color: #000000;
}

/* mouse over link */
.not-active:hover {
    color: #000000;
}

/* selected link */
.not-active:active {
    color: #000000;
}
</style>
</head>

<body>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">   
	  <a href="#" class="not-active scroll-top animated fadeIn "><h1>WELCOME DR. <?php echo $doctor_details['FirstName'].' '.$doctor_details['LastName']  ?></h1></a>
      </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse ">
        <ul class="nav navbar-nav" id="mainNav">
		  <li></li>
		  <li><a href="#patient_details" class="scroll-link">Patients details</a></li>
       <li><a href="../summary/sum_search.php" class="scroll-link">Patients summeary</a></li>
          <li><a href="#setting" class="scroll-link">Manage profile</a></li>
          <li><a href="../index.php" class="scroll-link">Log out</a></li> <!-- connect with loging page -->
        </ul>
      </div>
	 
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>
<!--/.header-->

<br>
<section id="patient_details" class="page-section color">
  <div class="container">
    <div class="heading text-center"> 
      <!-- Heading -->
      <h2>Patients details</h2>
    </div>	
<div class="container">
<div class="panel">
<div class="col-sm-6">
<form action="" method="POST">
<div class="panel panel-default">
    <div class="panel-heading clearfix"> 
        <span class="glyphicon glyphicon-th"></span> 
        <b>Search Patient Using ID</b>
        <div class="pull-right">
          <button type="submit"  class="btn btn-primary " name="id_search" value="Search">
             <span class="glyphicon glyphicon-search"></span>
          </button>
        </div>
    </div>
    <div class="panel clearfix">
    <div class="form-group">
      <input type="number" class="form-control" placeholder="Enter Patient ID" name="patient_id">
    </div>
  </form>
</div>
</div></div>
<div class="panel">
<div class="col-sm-6">
<form action="" method="POST">
<div class="panel panel-default">
    <div class="panel-heading clearfix"> 
        <span class="glyphicon glyphicon-th"></span> 
        <b>Search Patient Using Name</b>
        <div class="pull-right">
          <button type="submit" class="btn btn-primary" name="name_search" value="Search">
             <span class="glyphicon glyphicon-search"></span>
          </button>
        </div>
    </div>
    <div class="panel clearfix">
      <input type="text" class="form-control" placeholder="Enter Patient Name" name="patient_name">
	</div>
	</div>
  </form>
  </div></div>
  </div>
  <!--/.container--> 
</section>

<section id="patients">
<?php
require_once('search.php');

?>
</section>


<!--<section id="setting" class="page-section color">
  <div class="container">
    <div class="heading text-center"> 
      
      <h2>Manage profile</h2>
     </div>
	 </div>
</section>-->
   
<script src="../js/modernizr-latest.js"></script> 
<script src="../js/jquery-1.8.2.min.js" type="text/javascript"></script> 
<script src="../js/bootstrap.min.js" type="text/javascript"></script> 
<script src="../js/jquery.isotope.min.js" type="text/javascript"></script> 
<script src="../js/fancybox
/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="../js/jquery.nav.js" type="text/javascript"></script> 
<script src="../js/jquery.fittext.js"></script> 
<script src="../js/waypoints.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script> 
<script src="../js/owl-carousel/owl.carousel.js"></script>

</body>
</html>                 